
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
//hossein_nikbakht
int n = 0, choice=0,count_id=100;
struct product_info
{
	int id = 0;
	string name = "";
	int price = 0;
	int count = 0;
}*products, t;

int menu();
void show_list();
void load();
void write();
void Add_Product();
int search(int = 0, int = 1);
void Edit();
void print();
void delete_();
void buy();

int main()
{
	write();
	products = new product_info[n];
	while (choice != 7)
	{
		load();
		choice = menu();
		switch (choice)
		{
		case 1:
			Add_Product();
			break;
		case 2:
			Edit();
			break;
		case 3:
			delete_();
			break;
		case 4:
			search();
			break;
		case 5:
			show_list();
			break;
		case 6:
			buy();
			break;
		case 7:
			print();
			cout << "End." << endl;
			break;
		default:
			cout << "The number entered id out of the menu! Try again" << endl;
			break;
		}
		system("pause");
		system("cls");
	}
	delete[] products;
	return 0;
}



void load()
{
	if (choice == 1) {
		delete[] products;
		products = new product_info[n];
	}
	string line;
	ifstream Product_info;
	Product_info.open("products.txt");
	int k = 0;
	while (getline(Product_info, line))
	{
		string array[4];
		int j = 0;
		for (int i = 0; i <= line.length(); i++)
		{
			if (line[i] != ',' && line[i] != NULL)
				array[j] = array[j] + line[i];
			else
			{
				switch (j)
				{
				case 0:
					products[k].id = stoi(array[j]);
					break;
				case 1:
					products[k].name = array[j];
					break;
				case 2:
					products[k].price = stoi(array[j]);
					break;
				case 3:
					products[k].count = stoi(array[j]);
					break;
				}
				j++;
			}
		}
		k++;
	}
	Product_info.close();
}
void write()
{
	ofstream Product_info;
	Product_info.open("products.txt");
	Product_info << "101,apple,30000,40" << endl;
	Product_info << "102,mango,40000,20" << endl;
	Product_info << "103,watermelone,5000,100";
	n = 3;
	count_id += 3;
	Product_info.close();
}

void show_list()
{
	for (int i = 0; i < n; i++)
		cout << "\nProduct " << i + 1 << ": id:" << products[i].id << "\tname:" << products[i].name << "\tprice:" << products[i].price << "\tcount:" << products[i].count;
	cout << endl;
}

int menu()
{
	int c;
	cout << "\n\t STORE MENU\n1-Add Product\n2-Edit Product\n3-Delete Product\n4-Search\n5-Show list\n6-Buy\n7-Exit\nEnter your choice: ";
	cin >> c;
	return c;
}

void Add_Product() {
	n++;
	count_id++;
	ofstream Product_info;
	Product_info.open("products.txt", ios::app);
	t.id = count_id;
	cout << "id:\t" << t.id << endl;
	cout << "Enter name: ";
	cin >> t.name;
	cout << "Enter price: ";
	cin >> t.price;
	cout << "Enter count: ";
	cin >> t.count;
	Product_info << endl << t.id << "," << t.name << "," << t.price << "," << t.count;
	Product_info.close();
}

void Edit() {
	int ID;
	cout << "Enter ID for Edit:";
	cin >> ID;
	int i = search(ID);
	if (i != -1) {
		int c,flag=1;
		cout << "1-Edit name\n2-Edit price\n3-Edit count\nEnter your choice: ";
		cin >> c;
		switch (c)
		{
		case 1:
			cout << "Enter new name: ";
			cin >> products[i].name;
			break;
		case 2:
			cout << "Enter new price: ";
			cin >> products[i].price;
			break;
		case 3:
			cout << "Enter new count: ";
			cin >> products[i].count;
			break;
		default:
			cout << "wrong input! try again." << endl;
			flag = 0;
			break;
		}
		if (flag == 1)
			cout << "Edit successfuly." << endl;
	}
	print();
}
void print() {
	ofstream Product_info;
	Product_info.open("products.txt");
	for (int i = 0; i < n; i++)
	{
		if (i != 0)
			Product_info << endl;
		Product_info << products[i].id << "," << products[i].name << "," << products[i].price << "," << products[i].count;
	}
	Product_info.close();
}

void delete_()
{
	int ID;
	cout << "Enter ID for delete:";
	cin >> ID;
	int i = search(ID);
	if (i != -1) {
		for (int j = i; j < n - 1; j++)
			products[i] = products[i + 1];
		n--;
		cout << "Delete successfuly." << endl;
		print();
	}
}

int search(int d, int c)
{
	int ID;
	string name;

	if (d == 0) {
		cout << "1-search by ID\n2-search by Name\nEnter your choice: ";
		cin >> c;
	}
	else
		ID = d;
	
	if (c == 1) {
		if (d == 0) {
			cout << "Enter ID for search:";
			cin >> ID;
		}
		for (int i = 0; i < n; i++)
			if (products[i].id == ID) {
				if (d == 0)
					cout << "\nProduct : id:" << products[i].id << "\tname:" << products[i].name << "\tprice:" << products[i].price << "\tcount:" << products[i].count << endl;
				return i;
			}
		cout << "Product not found!" << endl;
	}
	else if (c == 2) {
		cout << "Enter Name for search:";
		cin >> name;
		for (int i = 0; i < n; i++)
			if (products[i].name == name){
				cout << "\nProduct : id:" << products[i].id << "\tname:" << products[i].name << "\tprice:" << products[i].price << "\tcount:" << products[i].count << endl;
				return i;
			}
		cout << "Product not found!" << endl;
	}
	else
		cout << "wrong input! try again." << endl;
	return -1;
}

void buy()
{
	int Exit;
	int list[100], m = 0,count_list[100];

	do
	{
		int ID;
		cout << "Enter ID for buy:";
		cin >> ID;
		int i = search(ID);
		if (i != -1) {
			int count;
			cout << "Enter the number of products you want: ";
			cin >> count;
			if (count <= products[i].count) {
				products[i].count -= count;
				count_list[m] = count;
				list[m] = i;
				m++;
			}
			else
				cout << "Not as meny products as you want!";
		}
		cout << "1-Buy again.\n2-Exit\nEnter your choice: ";
		cin >> Exit;
	} while (Exit!=2);
	int sum = 0;
	cout << "\n-------------- Your shopping list --------------\n";
	for (int i = 0; i < m; i++)
	{
		cout << "name:" << products[list[i]].name << "\tprice:" << products[list[i]].price << "\tcount:" << count_list[i] << endl;
		sum += (products[list[i]].price*count_list[i]);
	}
	cout << "\nTotal price = " << sum << endl;
	print();
}
